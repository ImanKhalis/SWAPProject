<!DOCTYPE html>
<html>
<style>
.center {
    text-align: center;
}
</style>
<div class="center">
<body>
<h1> Welcome to <i>MeatLa</i> Admin Login </h1>
<p> Please enter Username and Password </p>
	<form action="MainAdmin.php" method="POST">
	  Username: <input type="text" name="username"/><br>
	  Password : <input type="password" name="password"/><br>
	  <br>
	  <input type="submit" value="Login">
	</form>
	</div>
</body>
</html>