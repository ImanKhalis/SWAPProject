<html>
<body>
<h1>Updating Customer User Account</h1>
<p><font size="5"> Please Update Customer Information </font></p>
<form action="updated.php" method="post">
Customer ID: <input type="text" name="customid"/><br>
Customer Name: <input type="text" name="customname"/><br>
Contact Number: <input type="text" name="contact" maxlength="8"/><br>
<br>
<input type="submit" value="Confirm"><a href="updated.php">
<a href="MainAdmin.php"><button type="button"> Cancel </button> </a>
</html>