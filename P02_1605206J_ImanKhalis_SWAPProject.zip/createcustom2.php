<html>
<body>  
<?php
$con = mysqli_connect("localhost","root","","meatla");
if (!$con){
	die('Could not connect: ' . mysqli_connect_errno());
}
$customid=($_POST["customid"]);
$customname=($_POST["customname"]);
$contact=($_POST["contact"]);

$createsql = "INSERT INTO customer (Customer_ID, Customer_Name, Contact_Number) VALUES ('$customid','$customname', $contact)";

if ($con->query($createsql) == TRUE)
{
	echo "Successfully inserted!";
}
else
{
	echo "Error!";
}

$con->close();
?>
</br>
</br>
<a href="MainAdmin.php"><button type="button"> Back </button> </a>
</html>