<html>
<body>
<h1>Deleting an Order</h1>
<?php
$con = mysqli_connect("localhost","root","","meatla");
if (!$con){
	die('Could not connect: ' . mysqli_connect_errno());
}

$readsql = "SELECT * FROM `customer`";
if ($con->query($readsql) == TRUE)
{
	echo "Reading All User Accounts <br>";
	echo "<br>";
	$result = mysqli_query($con, $readsql);
	while($row = mysqli_fetch_assoc($result)) 
        {
            echo "Customer ID: " . $row["Customer_ID"]. " | Name: " . $row["Customer_Name"]. " | Contact Number: " . $row["Contact_Number"]. "<br>"; 
        }
}
else
{
	echo "Error!";
	}
$con->close();
?>
<h3> Select a User to Remove </h3>
<form action="confirm2.php" method="post">
User ID: <input type="text" name="userid"/><br>
<br>
<input type="submit" value="Confirm"><a href="confirm.php">
<a href="MainAdmin.php"><button type="button"> Back </button> </a>
</html>