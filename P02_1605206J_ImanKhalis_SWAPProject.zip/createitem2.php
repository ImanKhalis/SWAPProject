<html>
<body>  
<?php
$con = mysqli_connect("localhost","root","","meatla");
if (!$con){
	die('Could not connect: ' . mysqli_connect_errno());
}
$itemid=($_POST["itemid"]);
$itemdesc=($_POST["itemdesc"]);

$createsql = "INSERT INTO item (Item_ID, Item_Description) VALUES ('$itemid','$itemdesc')";

if ($con->query($createsql) == TRUE)
{
	echo "Successfully inserted!";
}
else
{
	echo "Error!";
}

$con->close();
?>
</br>
</br>
<a href="MainAdmin.php"><button type="button"> Back </button> </a>
</html>