<html>
<body>  
<?php
$con = mysqli_connect("localhost","root","","meatla");
if (!$con){
	die('Could not connect: ' . mysqli_connect_errno());
}
$customid=($_POST["customid"]);
$customname=($_POST["customname"]);
$contact=($_POST["contact"]);

$updatesql = "UPDATE customer SET Customer_ID = '$customid', Customer_Name = '$customname', Contact_Number = '$contact' WHERE customer.Customer_ID = '$customid'";

if ($con->query($updatesql) == TRUE)
{
	echo "Successfully updated!";
	}
else
{
	echo "Error!";
	}

$con->close();
?>
<br>
<br>
<a href="MainAdmin.php"><button type="button"> Back </button> </a>
</html>