<html>
<body>
<h1>Creating New Customer User Account</h1>
<p><font size="5"> Fill in Customer Information </font></p>
<form action="createcustom2.php" method="post">
Customer ID: <input type="text" name="customid"/><br>
Customer Name: <input type="text" name="customname"/><br>
Contact Number: <input type="text" name="contact" maxlength="8"/><br>
<br>
<input type="submit" value="Confirm"><a href="createcustom2.php">
<a href="MainAdmin.php"><button type="button"> Cancel </button> </a>
</form>
</html>