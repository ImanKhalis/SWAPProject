<html>
<body>  
<?php
$con = mysqli_connect("localhost","root","","meatla");
if (!$con){
	die('Could not connect: ' . mysqli_connect_errno());
}

$readsql = "SELECT `Item_ID`, `Item_Description` FROM `item`";

if ($con->query($readsql) == TRUE)
{
	echo "Reading available items <br>";
	echo "<br>";
	$result = mysqli_query($con, $readsql);
	while($row = mysqli_fetch_assoc($result)) 
        {
            echo "Item ID: " . $row["Item_ID"]. " | " . $row["Item_Description"]. "<br>"; 
        }
	}
else
{
	echo "No orders";
	}

$con->close();
?>
<br>
<br>
<a href="MainAdmin.php"><button type="button"> Back </button> </a>
</html>