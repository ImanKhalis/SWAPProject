<html>
<body>
<h1>Deleting an Order</h1>
<?php
$con = mysqli_connect("localhost","root","","meatla");
if (!$con){
	die('Could not connect: ' . mysqli_connect_errno());
}

$readsql = "SELECT `Order_ID`, `Item_ID`, `Quantity`, `Customer_ID`, `Date`, `Status` FROM `order`";

if ($con->query($readsql) == TRUE)
{
	echo "Reading delivered items <br>";
	echo "<br>";
	$result = mysqli_query($con, $readsql);
	while($row = mysqli_fetch_assoc($result)) 
        {
            echo "Order ID: " . $row["Order_ID"]. " | Item ID: " . $row["Item_ID"]. " | Quantity: " . $row["Quantity"]. " | Customer ID: " . $row["Customer_ID"]. " | Date: " . $row["Date"]. " | Status: " . $row["Status"]."<br>"; 
        }
	}
else
{
	echo "No orders";
	}
$con->close();
?>
<h3> Select an Order to Delete </h3>
<form action="confirm.php" method="post">
Order ID: <input type="text" name="orderid"/><br>
<br>
<input type="submit" value="Confirm"><a href="confirm.php">
<a href="MainAdmin.php"><button type="button"> Back </button> </a>
</html>