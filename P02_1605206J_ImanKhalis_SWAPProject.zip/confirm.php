<html>
<body>
<h1>The following has been deleted</h1>
<?php
$con = mysqli_connect("localhost","root","","meatla");
if (!$con){
	die('Could not connect: ' . mysqli_connect_errno());
}

$orderid=($_POST["orderid"]);

$readsql = "SELECT `Order_ID`, `Item_ID`, `Quantity`, `Customer_ID`, `Date`, `Status` FROM `order` WHERE Order_ID = '$orderid'";

if ($con->query($readsql) == TRUE)
{
	$result = mysqli_query($con, $readsql);
	while($row = mysqli_fetch_assoc($result)) 
        {
            echo "Order ID: " . $row["Order_ID"]. " | Item ID: " . $row["Item_ID"]. " | Quantity: " . $row["Quantity"]. " | Customer ID: " . $row["Customer_ID"]. " | Date: " . $row["Date"]. " | Status: " . $row["Status"]."<br>"; 
        }
	}
else
{
	echo "No orders";
	}
$deletesql = "DELETE FROM `order` WHERE Order_ID = '$orderid'";

if ($con->query($deletesql) == TRUE)
{
	echo "<br>";
	}
else
{
	echo "Error!";
	}
$con->close();
?>
</html>
<br>
<br>
<a href="MainAdmin.php"><button type="button"> Back </button> </a>
</html>