<html>
<style>
.center {
    text-align: center;
}
</style>
<div class="center">
<p><font size="7"><b>Select a function </b></font></p>
</div>
<h2> CREATE </h2>
<a href="createcustom.php">Create New Customer User Account</a> <br>
<a href="createitem.php">Add Grocery Item</a>
<br>
<br>
<br>
<h2> READ </h2>
<a href="readorder.php">Read Customer Order</a> <br>
<a href="readgrocery.php">Read Grocery Item</a> <br>
<br>
<br>
<br>
<h2> UPDATE </h2>
<a href="updatecustom.php">Update Customer Particulars</a> <br>
<br>
<br>
<br>
<h2> DELETE </h2>
<a href="deleteorder.php">Delete Order</a> <br>
<a href="deletecustomer.php">Delete Customer User Account</a> <br>
<br>
<br>
<br>
</html>