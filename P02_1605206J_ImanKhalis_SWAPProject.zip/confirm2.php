<html>
<body>
<h1>The following has been deleted</h1>
<?php
$con = mysqli_connect("localhost","root","","meatla");
if (!$con){
	die('Could not connect: ' . mysqli_connect_errno());
}

$userid=($_POST["userid"]);

$readsql = "SELECT `Customer_ID`, `Customer_Name`, `Contact_Number` FROM `customer` WHERE Customer_ID = '$userid'";

if ($con->query($readsql) == TRUE)
{
	$result = mysqli_query($con, $readsql);
	while($row = mysqli_fetch_assoc($result)) 
        {
            echo "Customer ID: " . $row["Customer_ID"]. " | Name: " . $row["Customer_Name"]. " | Contact Number: " . $row["Contact_Number"]. "<br>";
        }
	}
else
{
	echo "No orders";
	}
$deletesql = "DELETE FROM `customer` WHERE Customer_ID = '$userid'";

if ($con->query($deletesql) == TRUE)
{
	echo "<br>";
	}
else
{
	echo "Error!";
	}
$con->close();
?>
</html>
<br>
<br>
<a href="MainAdmin.php"><button type="button"> Back </button> </a>
</html>