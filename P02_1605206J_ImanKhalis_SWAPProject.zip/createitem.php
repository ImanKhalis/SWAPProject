<html>
<body>
<h1>Adding New Grocery Item</h1>
<p><font size="5"> Fill in Grocery Information </font></p>
<form action="createitem2.php" method="post">
Item ID: <input type="text" name="itemid"/><br>
Item Name: <input type="text" name="itemdesc"/><br>
<br>
<input type="submit" value="Confirm"><a href="createitem2.php">
<a href="MainAdmin.php"><button type="button"> Cancel </button> </a>
</form>
</html>